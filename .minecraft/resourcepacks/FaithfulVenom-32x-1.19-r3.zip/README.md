# FaithfulVenom 32x

**Current Branch Version:** _1.19-r3_  

## Official Links

Downloads: https://antvenom.com/files  
Discord: https://discord.gg/AntVenom  
GitHub Repo: https://github.com/mullak99s-Faithful/FaithfulVenom  
Issues: https://github.com/mullak99s-Faithful/FaithfulVenom/issues  
